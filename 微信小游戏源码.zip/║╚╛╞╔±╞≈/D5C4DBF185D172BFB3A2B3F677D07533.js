function t(e, o) {
    return module.exports = t = Object.setPrototypeOf || function(t, e) {
        return t.__proto__ = e, t;
    }, t(e, o);
}

module.exports = t;