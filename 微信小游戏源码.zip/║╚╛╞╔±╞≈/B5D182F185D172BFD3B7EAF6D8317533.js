var e = require("76C4400185D172BF10A22806F8607533.js");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var r = e(require("8C8B620485D172BFEAED0A0348107533.js")), t = e(require("2987505485D172BF4FE13853ABC07533.js")), u = e(require("C263A5B085D172BFA405CDB76D407533.js")), l = e(require("3D1BA7C285D172BF5B7DCFC52C507533.js")), i = function(e) {
    function i(e, l) {
        var a;
        return (0, r.default)(this, i), (a = (0, t.default)(this, (0, u.default)(i).call(this, l))).code = e, 
        a;
    }
    return (0, l.default)(i, e), i;
}((0, e(require("910F0A1085D172BFF7696217D6117533.js")).default)(Error));

exports.default = i;