Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.SIZE_LIST = exports.MINI_PROGRAM = exports.PAY_GOODS_ID = exports.GAME_LIST = exports.SKIN_LIST = exports.FOCUS_IMAGE_URL = exports.SOURCE_TYPE = exports.AD_TYPE = exports.ERROR_CODE = exports.ROOM_STATE = exports.MEASURES = void 0, 
exports.MEASURES = {
    drink: [ "喝半杯", "喝一杯", "喝两杯", "喝三杯", "喝一瓶", "不喝", "一小口", "敬在场的所有异性酒", "敬在场的所有同性酒", "抽中三次免单", "抽中三次买单", "找一个异性喝交杯酒", "大家干杯", "找人干杯", "随意喝", "杯子里喝光", "上家喝光", "下家喝光" ],
    truth: [ "你的初吻是几岁在什么地方被什么人夺去的?", "你的初恋是几岁?", "你的初恋对象是谁?", "大学一共挂过几门课？", "大学所有考试中，你考到最低的一门是什么课，考了几分？", "你吻过几个人？", "在现场所有同学中，你看哪位异性同学最舒服？", "如果再给你一次机会，回到高中毕业那天，你最想对某一位异性说什么话？", "第一个喜欢的异性叫什么名字？", "你曾经意淫过在场的哪一位？如果过去没有的话，你现在会选哪一位作为YY对象？", "对梦中情人有什么要求（在一分钟内说出五条）", "让你一直念念不忘的一位异性的名字？原因？", "谈过几次恋爱？", "每天睡觉前都会想起的人是谁？", "你最怕的事情或东西是什么（说出三件）", "你会不会在意ta的过去，为什么？", "打算什么时候结婚？", "现在心里最在意的异性叫什么名字？", "第一次爱的人对你有什么影响？", "你在意你的老婆（老公）不是处女（处男）吗？", "你会为了爱情牺牲一切，包括生命吗？", "结婚后希望生男孩还是女孩(只能选择一个，说出原因)。", "和多少异性有过非恋爱的暧昧关系？", "你作弊使用过的最高招", "从小到大最丢脸出丑的事情是什么？", "如果明天是世界末日，你现在最想做的是什么？", "如果让你kiss现场的某一位异性，你会选择谁，为什么？", "说出同寝室的人最让你受不了的习惯", "最欣赏自己哪个部位？对自己哪个部位最不满意？", "最后一次发自内心的笑是什么时候？", "愿意为爱情牺牲到什么程度", "身上哪个部位最敏感", "你会选择Having sex before marriage吗？", "如果让你选择做一个电影中的角色，你会选谁呢？", "哭得最伤心的是哪一次？为什么？", "如果跟你喜欢的人约会，碰到前任的男（女）朋友，会有什么表现？", "如果请你从在座的里面选一位做你的男女朋友,你会选谁?", "上一次接吻的是什么时候？和谁？", "暗恋过几个异性？有主动追求过吗？", "哪个颜色的内衣最多？今天穿什么颜色？", "你会期待一夜情吗？", "会经常便秘吗?", "你身上有没有胎记？长在什么地方，什么形状？", "理想中的另一半是什么样子？", "在和男、女朋友交往的过程中，有被甩过吗？", "说出五种避孕方式？", "你是否会有时孤枕难眠？", "你是处女、处男吗？", "请讲述第一次恋爱的情景？", "请讲述未来5年的事业规划？", "你认为男人善变还是女人善变？", "你在寂寞时，会想起谁？", "只给你一天时间当异性，你最想做什么？", "自己最宝贵的财富是什么？", "你父母的生日是何时？有给他们过过生日吗？", "你觉得活着的意义是什么？", "生过的最严重的病是什么？", "觉得自己处理的最糟糕的事情是哪一件？", "讲述自己最得意的一件事情？", "第一次性经历是何时？", "平生最成功的一次撒谎？", "你在决定婚姻的时候，物质和感情占怎么样的比重？", "每个月的开销是多少？花到哪去了？", "你会不会向自己暗恋的人表白?怎么样表白？", "你认为女生都是很现实的吗?", "为什么男人不坏，女人不爱？", "该怎样舌吻?", "你认为最浪漫的事情是什么?", "你的BRA是什么尺寸?", "你认为男生就该养家吗?", "你会接受平胸ＭＭ吗？", "喜欢男女生做些什么小动作？", "你听过、说过的最感人的情话？", "你接受姐弟恋吗？几岁的范围可以接受？", "思想出轨和身体出轨，哪个比较能够接受？", "什么样算是分手最佳方式?", "你说女友该不该花男友的钱？", "你会选择爱还是被爱？", "如果一天之内要用光十个亿，你要怎么样花？", "你最讨厌什么样的人？", "觉得自己的脸皮厚还是薄？", "你觉得自己放的屁臭不臭？", "在座你最想打的人是谁？", "你最短的一次恋爱是什么情况", "你觉得什么样式的内裤最性感", "你和在座的一位异性都干过恋人之间的什么事", "会在婚前跟恋人发生关系么", "多久换一次内裤", "你的小癖好是什么", "你喜欢裸睡么", "你在感情上劈过腿没有", "你觉得自己最郁闷的外号是什么", "和恋人的身体接触到哪一步了", "你认为在座谁最性感", "认同没有性的爱情么", "去你喜欢的人家里想拉肚子怎么办", "初吻是在什么情况下没有的", "最奢侈的一次消费是什么", "如果看到自己最爱的人熟睡在你面前你会做什么？", "当你最不知道穿什么颜色的时候，你会选择什么颜色？", "今年你最后悔的一件事是什么？", "你最想要的5样东西", "最后一次发自内心的笑是什么时候？", "如果给你一个机会去世界上任何一个地方旅行你会去?", "如果时间能倒流你希望回到哪一时间？", "你心目中理想的爱人是什么样子呢？", "最想实现的三个愿望是什么？", "如果有来生，你选择当？", "如果有一天，你生命中最重要的东西离你而去了，你会怎么办？", "世界末日，你会幸存，并且你可以救一个人，你会怎么做？", "如果让你选择做一个电影中的角色，你会选谁呢？", "你在乎别人看你的眼光吗？会为了众人的反对放弃自己想要的东西或人吗？", "你的爱人要出国，你会怎么做？", "如果能预知未来，你最不希望看见的是什么？", "你认为多交朋友的好处在哪里？", "哭得最伤心的是哪一次？为什么？", "你觉得最美的画面是什么？", "如果跟你喜欢的人约会，碰到前任的男（女）朋友，会有什么表现？", "到目前为止你做过最疯狂的事是？", "你最不能忍受左边的人的哪一点？", "你最不能忍受右边的人的哪一点？" ],
    risk: [ "背一位异性绕场一周", "唱青藏高原最后一句", "做一个大家都满意的鬼脸", "抱一位异性直到下一轮真心话大冒险结束", "像一位异性表白3分钟", "与一位异性十指相扣，对视10秒", "邀请一位异性为你唱情歌，或邀请一位异性与你情歌对唱", "做自己最性感、最妩媚的表情或动作", "吃下每个人为你夹得菜", "跳海草舞", "唱学猫叫", "蹲在凳子上作便秘状", "亲离自己最近的一位异性，部位不限", "深情的吻墙10秒", "模仿古代特殊职业女子拉客", "模仿脑白金广告，边唱边跳", "用胳膊从正面量最近的一位异性胸围", "原地转10圈（就近靠下）", "对外大喊我是猪", "大喊燃烧吧，小宇宙～", "选一个男生一边捶他的胸一边说：你好讨厌哦", "一人先用嘴吸住一纸牌，另一人用嘴从另一面将纸牌吸住移走", "女生仰躺地上，男生撑在上面，做五下俯卧撑", "男生仰躺地上，女生撑在上面，坚持5秒钟", "喝咸味的饮料或辣的汤", "扮演4个猪八戒经典动作。", "挑在场的任意一个异性朋友（或指定），牵起她/他的手，神情对望30秒", "对着墙壁说，我很傻我非常傻，我超级大傻蛋。", "对窗外大喊“我好寂寞啊”", "找一男生把腿架他肩膀上让他捶腿", "亲左数第二个异性的额头", "和左边第一个异性换穿上衣", "在厕所里唱歌，让大家都能听到唱的是什么", "左手拉右耳，右手拉左耳，从桌子底下过", "穿自己的外套表演张倾城之“我脱、我穿、我再脱、我再穿”", "露出肚皮，扭腰扭屁股，各扭3圈", "和右边第一个异性关在厕所里等一轮游戏", "用手纸当围巾，围脖子上持续一轮游戏", "为右边第一个男生脱衣服，由下一轮抽中的人再为他穿上", "任选两个男生一起摆芙蓉姐姐的S形", "把右边第一个 异性横抱起来", "慢慢地性感地 把上衣撩起到不能再撩起的位置", "对在场的一位异性说一分钟情话，不能冷场哦！", "给大家唱一首对你有特殊意义的歌，并说出理由。", "右手扭住左耳垂，弯下腰，顺时针转10圈，再金鸡独立15秒", "右手跨过后脑勺从左边摸右眼", "先大笑五秒钟再大哭五秒钟，重复2-3次", "用舌头舔自己的胳膊肘", "背现场年龄最小的走一圈", "选一个人跟你离开房间五分钟", "喝掉左边第二位同性为你调的酒", "手指蘸上食物，用嘴性感的方式舔完", "饶你一命，换下个人", "坐在左边第一位异性的大腿上，大家决定什么时候你能下来", "轻咬右侧第二位的耳垂", "在座每一个人打一下你的屁股", "哭泣状并深情亲吻墙壁10秒", "抱着垃圾桶傻笑五分钟", "把中指插进左边人的鼻孔并拍照留念", "随便打电话给一个陌生人聊天五分钟", "慢慢拨弄头发朝右边第三个异性眨眼", "被右边的两位玩家瘙痒10分钟", "拔一根鼻毛或腿毛", "选个人查看你的所有短信并允许读出来", "选个人查看你手机的所有照片并允许展示给大家", "一秒钟变格格", "蹲在厕所门口傻笑5分钟", "拜托一个男生和一个女生当众亲密拥抱一分钟", "随便给手机里的一个异性打电话。说：其实.....我是....猪。", "和右边第一个异性关在厕所里等一轮游戏", "男生单腿下跪，女生亲男生额头", "男生抱起女生，保持10秒钟", "男生面对面抱起来女生", "男生单腿下跪，亲女生手背", "选择一个异性与你隔纸亲吻" ]
}, exports.ROOM_STATE = {
    OWNER_READY: 1001,
    OWNER_STARTED: 1002
}, exports.ERROR_CODE = {
    SUCCESS: 0,
    NEED_LOGIN: 1,
    COMMON_EXCEPTION: 100,
    ROOM_NOT_EXIST: 104
}, exports.AD_TYPE = {
    HOME: "home"
}, exports.SOURCE_TYPE = {
    punishment: "喝酒认怂书"
}, exports.FOCUS_IMAGE_URL = "https://wxflag.afunapp.com/finger/focus.jpg", exports.SKIN_LIST = [ {
    skin_id: 1,
    name: "",
    checkin_days: 0,
    invite_total: 0,
    price: 0,
    imgurl: "https://wxflag.afunapp.com/uncle_head_1.png",
    resource: {
        head_imgurl: "https://wxflag.afunapp.com/uncle_head_1.png",
        dark_imgurl: "https://wxflag.afunapp.com/uncle_head_dark_1.png",
        select_imgurl: [ "https://wxflag.afunapp.com/uncle_selected_1_1.png", "https://wxflag.afunapp.com/uncle_selected_1_2.png" ],
        click_audio: "uncle_click",
        select_audio: "uncle_selected_1"
    }
}, {
    skin_id: 2,
    name: "",
    checkin_days: 0,
    invite_total: 3,
    price: 0,
    imgurl: "https://wxflag.afunapp.com/uncle_head_2.png",
    resource: {
        head_imgurl: "https://wxflag.afunapp.com/uncle_head_2.png",
        dark_imgurl: "https://wxflag.afunapp.com/uncle_head_dark_2.png",
        select_imgurl: [ "https://wxflag.afunapp.com/uncle_selected_2_1.png", "https://wxflag.afunapp.com/uncle_selected_2_2.png" ],
        click_audio: "uncle_click",
        select_audio: "uncle_selected_2"
    }
}, {
    skin_id: 3,
    name: "",
    checkin_days: 3,
    invite_total: 0,
    price: 0,
    imgurl: "https://wxflag.afunapp.com/uncle_head_3.png",
    resource: {
        head_imgurl: "https://wxflag.afunapp.com/uncle_head_3.png",
        dark_imgurl: "https://wxflag.afunapp.com/uncle_head_dark_3.png",
        select_imgurl: [ "https://wxflag.afunapp.com/uncle_selected_3_1.png", "https://wxflag.afunapp.com/uncle_selected_3_2.png" ],
        click_audio: "uncle_click",
        select_audio: "uncle_selected_3"
    }
}, {
    skin_id: 4,
    name: "",
    checkin_days: 0,
    invite_total: 5,
    price: 0,
    imgurl: "https://wxflag.afunapp.com/uncle_head_4.png",
    resource: {
        head_imgurl: "https://wxflag.afunapp.com/uncle_head_4.png",
        dark_imgurl: "https://wxflag.afunapp.com/uncle_head_dark_4.png",
        select_imgurl: [ "https://wxflag.afunapp.com/uncle_selected_4_1.png", "https://wxflag.afunapp.com/uncle_selected_4_2.png" ],
        click_audio: "uncle_click",
        select_audio: "uncle_selected_4"
    }
}, {
    skin_id: 5,
    name: "单身狗",
    checkin_days: 0,
    invite_total: 10,
    price: 0,
    imgurl: "https://wxflag.afunapp.com/uncle_head_5.png",
    resource: {
        head_imgurl: "https://wxflag.afunapp.com/uncle_head_5.png",
        dark_imgurl: "https://wxflag.afunapp.com/uncle_head_dark_5.png",
        select_imgurl: [ "https://wxflag.afunapp.com/uncle_selected_5_1.png", "https://wxflag.afunapp.com/uncle_selected_5_2.png" ],
        click_audio: "dog_click",
        select_audio: "uncle_selected_5"
    }
}, {
    skin_id: 6,
    name: "猪猪女孩",
    checkin_days: 5,
    invite_total: 0,
    price: 0,
    imgurl: "https://wxflag.afunapp.com/uncle_head_6.png",
    resource: {
        head_imgurl: "https://wxflag.afunapp.com/uncle_head_6.png",
        dark_imgurl: "https://wxflag.afunapp.com/uncle_head_dark_6.png",
        select_imgurl: [ "https://wxflag.afunapp.com/uncle_selected_6_1.png", "https://wxflag.afunapp.com/uncle_selected_6_2.png" ],
        click_audio: "pig_click",
        select_audio: "uncle_selected_6"
    }
} ], exports.GAME_LIST = [ {
    name: "找对象",
    data: {
        appId: "wx788f5daad54eb854"
    }
}, {
    name: "狼人杀",
    data: {
        appId: "wx92ba1cb06686bff1",
        path: "werewolf/page/pgs/room/room?ignoreReviewState=1"
    }
}, {
    name: "谁是卧底",
    data: {
        appId: "wxfc82ac24ee7e4b96"
    }
}, {
    name: "头像昵称",
    data: {
        appId: "wx6fd02174c7781825"
    }
} ], exports.PAY_GOODS_ID = {
    REMOVE_AD: 1001
}, exports.MINI_PROGRAM = 1, exports.SIZE_LIST = [ 3, 4, 5, 6 ];