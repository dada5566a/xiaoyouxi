var e = [ {
    1: "../../assets/image/dice/one@2x.png",
    2: "../../assets/image/dice/two@2x.png",
    3: "../../assets/image/dice/three@2x.png",
    4: "../../assets/image/dice/four@2x.png",
    5: "../../assets/image/dice/five@2x.png",
    6: "../../assets/image/dice/six@2x.png"
}, {
    1: "../../assets/image/dice/one_orange_yellow@2x.png",
    2: "../../assets/image/dice/two_orange_yellow@2x.png",
    3: "../../assets/image/dice/three_orange_yellow@2x.png",
    4: "../../assets/image/dice/four_orange_yellow@2x.png",
    5: "../../assets/image/dice/five_orange_yellow@2x.png",
    6: "../../assets/image/dice/six_orange_yellow@2x.png"
}, {
    1: "../../assets/image/dice/one_purple@2x.png",
    2: "../../assets/image/dice/two_purple@2x.png",
    3: "../../assets/image/dice/three_purple@2x.png",
    4: "../../assets/image/dice/four_purple@2x.png",
    5: "../../assets/image/dice/five_purple@2x.png",
    6: "../../assets/image/dice/six_purple@2x.png"
}, {
    1: "../../assets/image/dice/one_red@2x.png",
    2: "../../assets/image/dice/two_red@2x.png",
    3: "../../assets/image/dice/three_red@2x.png",
    4: "../../assets/image/dice/four_red@2x.png",
    5: "../../assets/image/dice/five_red@2x.png",
    6: "../../assets/image/dice/six_red@2x.png"
}, {
    1: "../../assets/image/dice/one_green@2x.png",
    2: "../../assets/image/dice/two_green@2x.png",
    3: "../../assets/image/dice/three_green@2x.png",
    4: "../../assets/image/dice/four_green@2x.png",
    5: "../../assets/image/dice/five_green@2x.png",
    6: "../../assets/image/dice/six_green@2x.png"
} ];

module.exports.dices = e;