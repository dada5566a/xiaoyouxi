function a0_0x457f() {
  var _0x19c1d7 = ['rotate', '33140DcdYtB', 'diceCupIdx', '../../../4B403BC085D172BF2D2653C78A727533.js', 'setData', 'floor', 'adunit-ef5bf71a45bdd710', 'playShakeDiceAnim', 'step', '/assets/dice/ui/btn_dice_disabled.png', 'diceNum', 'touches', '/pages/dice/treasure/treasure', '领取特权', 'play', '297745GSnmyE', 'getSeconds', 'setStorageSync', '16641oiIErn', '/dicecup_01.png', '444440pmYXnu', '1053296alnANg', 'globalData', 'https://xiaogao-1313575062.cos.ap-nanjing.myqcloud.com/29803200/diceSkin/dicecup1/dicecup_bottom.png', '今日特权已使用完毕(0/2)', 'yesterday', 'display:none;', 'success', 'isPrivilegeNum', 'loading', 'src', 'vibrateLong', '/assets/dice/dice/dice', '激励视频\x20广告显示失败', 'showToast', 'log', 'createInnerAudioContext', 'unLockDiceCup', 'onClose', '恭喜您已获取一次特权，点击\x22使用特权\x22使用吧～', '.png', 'push', 'diceCupDisplay', 'splice', 'currentTarget', 'display', 'getMonth', 'isLocked', 'privilegeNum', 'data', 'display:inline;', 'createAnimation', '/assets/friendShare.png', 'getFullYear', 'shake', 'seek', 'block', 'isEnded', 'getStorageSync', 'onError', 'canShake', '4266HsLkcC', 'privilegeDate', 'true', 'idx', 'isCashTask', 'none', '6RdwTiz', 'length', '【有人@你】我喊五个幺，你敢不敢开？', 'changeDice', 'previewImage', 'shakeDice', 'myAudio', '50%\x2060%', '网络较慢，请稍后重试！', 'privilegeBtnClo', 'coverDiceCup', 'lockDiceCup', '2662224WLMLwz', '\x22酒桌玩筛子\x22小程序，好友喝酒聚会神器，线上最全玩法，一起来叭~', '388CRWvnb', 'createRewardedVideoAd', 'formatTime(new\x20Date)', '3302285pydEcM', 'https://xiaogao-1313575062.cos.ap-nanjing.myqcloud.com/29803200/diceSkin/dicecup', 'ease', 'touchStartY', 'diceCupStyleIdx', 'random', 'wx.getStorageSync(\x27isPrivilegeNum\x27)', '/pages/index/index', 'pageY', 'navigateTo', '看完整版视频即可领取特权~', 'getMinutes', 'ceil', 'audioCtx'];
  a0_0x457f = function () {
    return _0x19c1d7;
  };
  return a0_0x457f();
}
var a0_0x51af38 = a0_0xf474;

function a0_0xf474(_0x1c0551, _0x2d88cc) {
  var _0x457fcb = a0_0x457f();
  return a0_0xf474 = function (_0xf474e2, _0x3771ab) {
    _0xf474e2 = _0xf474e2 - 0x72;
    var _0x5b62be = _0x457fcb[_0xf474e2];
    return _0x5b62be;
  }, a0_0xf474(_0x1c0551, _0x2d88cc);
}(function (_0x54d38d, _0x3388cb) {
  var _0x8e1c71 = a0_0xf474,
    _0x370b96 = _0x54d38d();
  while (!![]) {
    try {
      var _0x3c1c70 = -parseInt(_0x8e1c71(0x91)) / 0x1 + parseInt(_0x8e1c71(0x97)) / 0x2 + -parseInt(_0x8e1c71(0x94)) / 0x3 * (parseInt(_0x8e1c71(0xd3)) / 0x4) + -parseInt(_0x8e1c71(0x96)) / 0x5 * (parseInt(_0x8e1c71(0xc5)) / 0x6) + -parseInt(_0x8e1c71(0x74)) / 0x7 + -parseInt(_0x8e1c71(0xd1)) / 0x8 + parseInt(_0x8e1c71(0xbf)) / 0x9 * (parseInt(_0x8e1c71(0x83)) / 0xa);
      if (_0x3c1c70 === _0x3388cb) break;
      else _0x370b96['push'](_0x370b96['shift']());
    } catch (_0x475e29) {
      _0x370b96['push'](_0x370b96['shift']());
    }
  }
}(a0_0x457f, 0x59e83));
var e = getApp(),
  t = require(a0_0x51af38(0x85)),
  i = null,
  a = function (_0x38a580) {
    var _0x19bf9f = a0_0x51af38,
      _0x469551 = _0x38a580[_0x19bf9f(0xb7)](),
      _0x27c037 = _0x38a580[_0x19bf9f(0xb0)]() + 0x1,
      _0x4c7c21 = _0x38a580['getDate']();
    return _0x38a580['getHours'](), _0x38a580[_0x19bf9f(0x7f)](), _0x38a580[_0x19bf9f(0x92)](), String(_0x469551) + String(_0x27c037) + String(_0x4c7c21);
  },
  o = require(a0_0x51af38(0x85))[a0_0x51af38(0x9b)],
  c = Number(a(new Date()));
Page({
  'data': {
    'privilegePop': !0x1,
    'privilegeNum': null,
    'isPrivilege': !0x0,
    'privilegeDate': null,
    'isPrivilegeNum': 0x0,
    'isLighting': !0x1,
    'isSign': !0x0,
    'diceBottomUrl': a0_0x51af38(0x99),
    'btnDiceURL': '/assets/dice/ui/btn_dice_normal.png',
    'isLocked': !0x1,
    'animationData': {},
    'audioSrc': '',
    'diceUrl1': '',
    'diceUrl2': '',
    'diceUrl3': '',
    'diceUrl4': '',
    'diceUrl5': '',
    'diceUrl6': '',
    'dicePoints': [0x1, 0x1, 0x1, 0x1, 0x1, 0x1],
    'diceTypes': [0x1, 0x1, 0x1, 0x1, 0x1, 0x1],
    'diceSrcs': ['', '', '', '', '', ''],
    'diceStyles': ['', '', '', '', '', ''],
    'diceNum': 0x5,
    'diceCupColor': 0x0,
    'diceCupStyleIdx': 0x1,
    'diceCupDisplay': [],
    'guideNum': 0x0,
    'isCashTask': !0x1,
    'imageUrl': "/assets/dice/skin.png"
  },
  navigateToAnotherMiniProgram: function() {
    wx.navigateToMiniProgram({
      appId: 'wxc6987a9417083a02',
      path: 'pages/tabbar',
      extraData: {
        // 可以传递参数给目标小程序
      },
      success(res) {
        console.log('跳转成功')
      }
    })
  },
  'onLoad': function (_0x470233) {
    var _0x369518 = a0_0x51af38;
    this[_0x369518(0x81)] = wx[_0x369518(0xa6)](_0x369518(0xcb)), this['audioCtx'][_0x369518(0xa0)] = '/assets/dice/dice.mp3', this[_0x369518(0x81)]['seek'](0x0);
    var _0x5f20ac = wx[_0x369518(0xbc)]('diceNum');
    _0x5f20ac && this['setData']({
      'diceNum': _0x5f20ac
    });
    var _0x370f88 = wx[_0x369518(0xbc)](_0x369518(0x78));
    _0x370f88 && (this[_0x369518(0x86)]({
      'diceCupStyleIdx': _0x370f88,
      'diceCupUrl': _0x369518(0x75) + _0x370f88 + '/dicecup_01.png',
      'diceBottomUrl': _0x369518(0x75) + _0x370f88 + '/dicecup_bottom.png'
    }), this[_0x369518(0x81)]['seek'](0x0));
    var _0x52a677 = wx['getStorageSync']('diceCupColor');
    _0x52a677 && this[_0x369518(0x86)]({
      'diceCupColor': _0x52a677
    }), this[_0x369518(0x84)] = 0x1;
    for (var _0x2af95f = [], _0x5a942e = 0x1; _0x5a942e <= 0xc; _0x5a942e++) {
      var _0x178d80 = {};
      _0x178d80[_0x369518(0xc2)] = _0x5a942e < 0xa ? '0' + _0x5a942e : '' + _0x5a942e, _0x5a942e == this[_0x369518(0x84)] ? _0x178d80[_0x369518(0xaf)] = 'block' : _0x178d80[_0x369518(0xaf)] = _0x369518(0xc4), _0x2af95f[_0x369518(0xab)](_0x178d80);
    }
    this[_0x369518(0x86)]({
      'diceCupDisplay': _0x2af95f
    });
    try {
      wx[_0x369518(0xbc)]('isGuideShowed') || this[_0x369518(0x86)]({
        'guideNum': 0x1
      });
    } catch (_0x3392cb) {
      this[_0x369518(0x86)]({
        'guideNum': 0x1
      });
    }
    wx[_0x369518(0x72)] && (i = wx[_0x369518(0x72)]({
      'adUnitId': _0x369518(0x88)
    }))[_0x369518(0xbd)](function (_0x33ef0c) {});
  },
  'onHide': function () {
    wx['stopAccelerometer']();
  },
  'onShow': function () {
    var _0x45a386 = a0_0x51af38,
      _0x463894 = wx[_0x45a386(0xbc)](_0x45a386(0x78));
    _0x463894 && this[_0x45a386(0x86)]({
      'diceCupStyleIdx': _0x463894,
      'diceCupUrl': _0x45a386(0x75) + _0x463894 + _0x45a386(0x95),
      'diceBottomUrl': 'https://xiaogao-1313575062.cos.ap-nanjing.myqcloud.com/29803200/diceSkin/dicecup' + _0x463894 + '/dicecup_bottom.png'
    });
    var _0x5ce0e9 = setTimeout(function () {
      var _0x32323c = _0x45a386;
      t[_0x32323c(0xb8)](function () {
        var _0x3c3cc0 = _0x32323c,
          _0x51ee8b = getCurrentPages(),
          _0x330c78 = _0x51ee8b[_0x51ee8b[_0x3c3cc0(0xc6)] - 0x1];
        _0x330c78 && _0x330c78[_0x3c3cc0(0xca)] && _0x330c78[_0x3c3cc0(0xca)]();
      }), clearTimeout(_0x5ce0e9);
    }, 0x3e8);
  },
  'touchDiceCup': function (_0x33a0c4) {
    var _0x1e4f75 = a0_0x51af38;
    this[_0x1e4f75(0x77)] = _0x33a0c4[_0x1e4f75(0x8d)][0x0]['pageY'];
  },
  'moveDiceCup': function (_0x1aa0e0) {
    var _0x535f5c = a0_0x51af38,
      _0xc59f80 = _0x1aa0e0['touches'][0x0][_0x535f5c(0x7c)] - this[_0x535f5c(0x77)],
      _0x1acf8d = Math['ceil'](_0xc59f80 / -0x19);
    if (_0x1acf8d < 0x1 ? _0x1acf8d = 0x1 : _0x1acf8d > 0xc && (_0x1acf8d = 0xc), _0x1acf8d > 0xa ? this['setData']({
        'isLighting': !0x0
      }) : this['setData']({
        'isLighting': !0x1
      }), _0x1acf8d != this[_0x535f5c(0x84)]) {
      var _0x555826 = this[_0x535f5c(0xb3)][_0x535f5c(0xac)];
      _0x555826[this[_0x535f5c(0x84)] - 0x1][_0x535f5c(0xaf)] = _0x535f5c(0xc4), _0x555826[_0x1acf8d - 0x1][_0x535f5c(0xaf)] = 'block', this[_0x535f5c(0x86)]({
        'diceCupDisplay': _0x555826
      }), this[_0x535f5c(0x84)] = _0x1acf8d;
    }
  },
  'onMenuTap': function () {
    wx['navigateTo']({
      'url': '/pages/dice/setting/setting'
    });
  },
  'onBtnDiceTap': function () {
    var _0xffe63d = a0_0x51af38;
    this[_0xffe63d(0xb3)][_0xffe63d(0xb1)] ? this['unLockDiceCup']() : this[_0xffe63d(0xd0)]();
  },
  'playShakeDiceAnim': function () {
    var _0x4892f4 = a0_0x51af38,
      _0x83f769 = wx[_0x4892f4(0xb5)]({
        'transformOrigin': _0x4892f4(0xcc),
        'duration': 0x50,
        'timingFunction': _0x4892f4(0x76),
        'delay': 0x0
      });
    _0x83f769['rotate'](0x5 + Math['random']())[_0x4892f4(0x8a)]()[_0x4892f4(0x82)](-0x5)[_0x4892f4(0x8a)]()[_0x4892f4(0x82)](0x5)['step']()['rotate'](-0x5)[_0x4892f4(0x8a)]()[_0x4892f4(0x82)](0x5)['step']()[_0x4892f4(0x82)](-0x5)['step']()['rotate'](0x5)['step']()['rotate'](-0x5)['step']()[_0x4892f4(0x82)](0x5)[_0x4892f4(0x8a)]()['rotate'](0x0)['step'](), this[_0x4892f4(0x86)]({
      'animationData': _0x83f769['export']()
    });
  },
  'changeDice': function () {
    var _0x218a5e = a0_0x51af38;
    for (var _0x309282 = [], _0x234160 = [], _0x322658 = [], _0x3865d4 = [], _0x43e8ac = 0x0; _0x43e8ac < this['data']['diceNum']; _0x43e8ac++) _0x309282[_0x43e8ac] = Math[_0x218a5e(0x80)](0x6 * Math[_0x218a5e(0x79)]()), _0x234160[_0x43e8ac] = Math['ceil'](0x8 * Math[_0x218a5e(0x79)]()), _0x3865d4[_0x43e8ac] = '/assets/dice/dice/dice' + _0x309282[_0x43e8ac] + '_0' + _0x234160[_0x43e8ac] + '.png', _0x234160[_0x43e8ac], _0x322658[_0x43e8ac] = 'display:inline;';
    for (_0x43e8ac = 0x0; _0x43e8ac < 0x6 - this[_0x218a5e(0xb3)][_0x218a5e(0x8c)]; _0x43e8ac++) {
      var _0x4b5a1a = Math['floor'](Math[_0x218a5e(0x79)]() * (_0x3865d4[_0x218a5e(0xc6)] + 0x1));
      _0x3865d4['splice'](_0x4b5a1a, 0x0, ''), _0x322658['splice'](_0x4b5a1a, 0x0, _0x218a5e(0x9c));
    }
    console[_0x218a5e(0xa5)](_0x309282), this[_0x218a5e(0x86)]({
      'dicePoints': _0x309282,
      'diceTypes': _0x234160,
      'diceStyles': _0x322658,
      'diceSrcs': _0x3865d4
    });
  },
  'lockDiceCup': function () {
    var _0x4e7fab = a0_0x51af38;
    this[_0x4e7fab(0x86)]({
      'btnDiceURL': _0x4e7fab(0x8b),
      'isLocked': !0x0
    });
  },
  'unLockDiceCup': function () {
    this['setData']({
      'btnDiceURL': '/assets/dice/ui/btn_dice_normal.png',
      'isLocked': !0x1
    });
  },
  'coverDiceCup': function () {
    var _0x22d2bf = a0_0x51af38;
    this['diceCupIdx'] = 0x1;
    for (var _0x506253 = this['data']['diceCupDisplay'], _0x219b16 = 0x0; _0x219b16 < 0xc; _0x219b16++) _0x506253[_0x219b16]['display'] = _0x22d2bf(0xc4);
    _0x506253[0x0][_0x22d2bf(0xaf)] = _0x22d2bf(0xba), this['setData']({
      'diceCupDisplay': _0x506253
    });
  },
  'shakeDice': function () {
    var _0x689603 = a0_0x51af38;
    _0x55f15f = this;
    if (!this[_0x689603(0xb3)]['isLocked']) {
      console['log']('摇'), this[_0x689603(0x86)]({
        'isLighting': !0x1
      }), this[_0x689603(0xcf)](), this[_0x689603(0x81)][_0x689603(0xb9)](0x0), this[_0x689603(0x81)][_0x689603(0x90)](), this[_0x689603(0x89)](), this[_0x689603(0xc8)](), this[_0x689603(0xd0)]();
      var _0x55f15f = this,
        _0x325314 = setTimeout(function () {
          var _0x589fe8 = _0x689603;
          _0x55f15f[_0x589fe8(0xa7)](), clearTimeout(_0x325314);
        }, 0x3e8);
      if (e[_0x689603(0x98)][_0x689603(0xbe)] && wx[_0x689603(0xa1)]) _0x325314 = setTimeout(function () {
        var _0x13c5f5 = _0x689603;
        wx[_0x13c5f5(0xa1)]({}), clearTimeout(_0x325314);
      }, 0x12c);
    }
  },
  'stopPull': function () {},
  'onShareAppMessage': function () {
    var _0xa0bca0 = a0_0x51af38;
    return {
      'title': _0xa0bca0(0xc7),
      'path': _0xa0bca0(0x7b),
      'imageUrl': _0xa0bca0(0xb6)
    };
  },
  'onGuideTap': function () {
    var _0x50e6b9 = a0_0x51af38,
      _0x114800 = this[_0x50e6b9(0xb3)]['guideNum'] + 0x1;
    _0x114800 >= 0x5 && (_0x114800 = 0x0, wx['setStorageSync']('isGuideShowed', _0x50e6b9(0xc1))), this['setData']({
      'guideNum': _0x114800
    });
  },
  'treasureBtn': function () {
    var _0x225622 = a0_0x51af38;
    wx[_0x225622(0x7d)]({
      'url': _0x225622(0x8e)
    });
  },
  'privilegeBtnClo': function () {
    var _0x4eaa2e = a0_0x51af38;
    this[_0x4eaa2e(0x86)]({
      'privilegePop': !0x1
    });
  },
  'privilegeBtn': function () {
    var _0x3a52c2 = a0_0x51af38;
    this[_0x3a52c2(0x86)]({
      'privilegePop': !0x0
    }), wx['getStorageSync'](_0x3a52c2(0xb2)) ? this[_0x3a52c2(0x86)]({
      'privilegeNum': wx['getStorageSync'](_0x3a52c2(0xb2))
    }) : (wx[_0x3a52c2(0x93)](_0x3a52c2(0xb2), 0x0), this[_0x3a52c2(0x86)]({
      'privilegeNum': 0x0
    })), wx[_0x3a52c2(0xbc)](_0x3a52c2(0xc0)) || wx[_0x3a52c2(0x93)](_0x3a52c2(0xc0), c - 0x1), wx[_0x3a52c2(0xbc)](_0x3a52c2(0x9e)) || wx[_0x3a52c2(0x93)](_0x3a52c2(0x9e), 0x0);
  },
  'privilege': function (_0x18c256) {
    var _0xd8b220 = a0_0x51af38,
      _0x5c9943 = _0x18c256[_0xd8b220(0xae)]['dataset']['id'];
    console[_0xd8b220(0xa5)](_0xd8b220(0x8f), _0x18c256), console[_0xd8b220(0xa5)](_0xd8b220(0x7a), wx[_0xd8b220(0xbc)](_0xd8b220(0x9e)));
    var _0xf36786 = this;
    if (0x0 == _0x5c9943) {
      if (wx[_0xd8b220(0xbc)](_0xd8b220(0xc0)) == c) return wx[_0xd8b220(0xa4)]({
        'title': '领取次数已达上限，每天只能领取两次哦~',
        'duration': 0x9c4,
        'icon': _0xd8b220(0xc4),
        'mask': !0x0
      });
      i ? (i['show']()['catch'](function () {
        var _0x1812fe = _0xd8b220;
        wx[_0x1812fe(0xa4)]({
          'title': '网络较慢，请稍后重试！',
          'icon': _0x1812fe(0x9f),
          'duration': 0x7d0
        }), console['log'](_0x1812fe(0xa3));
      }), i[_0xd8b220(0xa8)](function (_0x3b0fba) {
        var _0x7983b0 = _0xd8b220;
        _0x3b0fba && _0x3b0fba[_0x7983b0(0xbb)] || void 0x0 === _0x3b0fba ? (i['offClose'](), wx[_0x7983b0(0xbc)](_0x7983b0(0xc0)) != c && 0x2 != wx[_0x7983b0(0xbc)](_0x7983b0(0x9e)) ? (wx[_0x7983b0(0x93)]('privilegeNum', wx[_0x7983b0(0xbc)](_0x7983b0(0xb2)) + 0x1), wx[_0x7983b0(0x93)]('isPrivilegeNum', wx[_0x7983b0(0xbc)](_0x7983b0(0x9e)) + 0x1), _0xf36786[_0x7983b0(0x86)]({
          'privilegeNum': wx[_0x7983b0(0xbc)](_0x7983b0(0xb2))
        }), 0x2 == wx['getStorageSync'](_0x7983b0(0x9e)) && (wx[_0x7983b0(0x93)](_0x7983b0(0xc0), Number(a(new Date()))), wx[_0x7983b0(0x93)](_0x7983b0(0x9e), 0x0)), wx[_0x7983b0(0xa4)]({
          'title': _0x7983b0(0xa9),
          'icon': 'none',
          'duration': 0x9c4
        })) : wx[_0x7983b0(0xa4)]({
          'title': _0x7983b0(0x9a),
          'icon': 'none',
          'duration': 0x9c4
        })) : wx[_0x7983b0(0xa4)]({
          'title': _0x7983b0(0x7e),
          'icon': _0x7983b0(0xc4),
          'duration': 0x5dc
        });
      })) : (wx[_0xd8b220(0xa4)]({
        'title': _0xd8b220(0xcd),
        'icon': _0xd8b220(0x9d),
        'duration': 0x7d0
      }), wx[_0xd8b220(0x93)]('privilegeDate', Number(o()))), console[_0xd8b220(0xa5)](_0xd8b220(0x73), a(new Date()), o());
    } else {
      if (0x1 == _0x5c9943) {
        if (wx[_0xd8b220(0xbc)](_0xd8b220(0xb2))) {
          for (var _0xee619 = Math[_0xd8b220(0x87)](0x6 * Math[_0xd8b220(0x79)]()) + 0x1, _0x54d272 = [_0xee619, Math[_0xd8b220(0x87)](0x6 * Math[_0xd8b220(0x79)]()) + 0x1, _0xee619, _0xee619, Math[_0xd8b220(0x87)](0x6 * Math[_0xd8b220(0x79)]()) + 0x1], _0x16d4cd = [], _0x206f20 = [], _0x38122b = [], _0x283727 = 0x0; _0x283727 < _0xf36786[_0xd8b220(0xb3)]['diceNum']; _0x283727++) _0x16d4cd[_0x283727] = Math[_0xd8b220(0x80)](0x8 * Math[_0xd8b220(0x79)]()), _0x38122b[_0x283727] = _0xd8b220(0xa2) + _0x54d272[_0x283727] + '_0' + _0x16d4cd[_0x283727] + _0xd8b220(0xaa), _0x16d4cd[_0x283727], _0x206f20[_0x283727] = _0xd8b220(0xb4);
          for (_0x283727 = 0x0; _0x283727 < 0x6 - _0xf36786[_0xd8b220(0xb3)][_0xd8b220(0x8c)]; _0x283727++) {
            var _0x2f376c = Math['floor'](Math[_0xd8b220(0x79)]() * (_0x38122b[_0xd8b220(0xc6)] + 0x1));
            _0x38122b[_0xd8b220(0xad)](_0x2f376c, 0x0, ''), _0x206f20['splice'](_0x2f376c, 0x0, _0xd8b220(0x9c));
          }
          console[_0xd8b220(0xa5)](_0x54d272), _0xf36786[_0xd8b220(0x86)]({
            'dicePoints': _0x54d272,
            'diceTypes': _0x16d4cd,
            'diceStyles': _0x206f20,
            'diceSrcs': _0x38122b
          }), wx[_0xd8b220(0x93)](_0xd8b220(0xb2), _0xf36786['data'][_0xd8b220(0xb2)] - 0x1), _0xf36786[_0xd8b220(0x86)]({
            'privilegeNum': wx[_0xd8b220(0xbc)](_0xd8b220(0xb2))
          }), this[_0xd8b220(0x81)]['seek'](0x0), this[_0xd8b220(0x81)][_0xd8b220(0x90)](), _0xf36786[_0xd8b220(0x89)](), _0xf36786[_0xd8b220(0xce)](), wx[_0xd8b220(0xa4)]({
            'title': '特权使用成功，请打开骰盖查看~',
            'icon': _0xd8b220(0xc4),
            'duration': 0x9c4
          });
        } else wx[_0xd8b220(0xa4)]({
          'title': '请观看视频广告才可以获取特权',
          'icon': 'none',
          'duration': 0x9c4
        });
      }
    }
  },
  'cashTaskShow': function () {
    var _0x70984f = a0_0x51af38;
    this[_0x70984f(0x86)]({
      'isCashTask': !this[_0x70984f(0xb3)][_0x70984f(0xc3)]
    });
  },
  'cashTaskCash': function () {
    var _0x1286c3 = a0_0x51af38;
    wx[_0x1286c3(0xc9)]({
      'urls': ['https://xiaogao-1313575062.cos.ap-nanjing.myqcloud.com/29803200/service/code.jpg?sign=96229b8be9d1c13d905e58fda4ab49a9&t=1622102430']
    });
  },
  'changeData': function () {
    var _0x3d108b = a0_0x51af38;
    this['onLoad'](), this[_0x3d108b(0xca)]();
  },
  'onShareTimeline': function () {
    var _0x447db5 = a0_0x51af38;
    return {
      'title': _0x447db5(0xd2),
      'imageUrl': _0x447db5(0xb6)
    };
  }
});