module.exports = function() {
    throw new TypeError("Invalid attempt to spread non-iterable instance");
};