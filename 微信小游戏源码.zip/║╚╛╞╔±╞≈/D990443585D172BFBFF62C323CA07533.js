module.exports = function() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance");
};